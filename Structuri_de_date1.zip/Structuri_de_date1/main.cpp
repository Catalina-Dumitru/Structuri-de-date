#include <iostream>

using namespace std;

int main()
{
    char  sir[100];
    cout<<"Introduceti cuvantul :";
    cin.getline(sir,31);
    //pentru a afla numarul de caractere al sirului folosim strlen
    int lungime_sir=strlen(sir);
}
//Cerinta 1 : SA se parcurga un sir de caractere si sa se afiseze daca sirul este palidrom de exemplu:"ana","radar"
/*
strlen: calculează și returnează lungimea unui șir de caractere.
strcat: concatenează două șiruri de caractere.
strcmp: compară două șiruri de caracter și returnează un număr negativ dacă primul șir este mai mic decât al doilea, zero dacă cele două șiruri sunt egale sau un număr pozitiv dacă primul șir este mai mare decât al doilea.
strchr: caută prima apariție a unui caracter într-un șir de caracter și returnează un pointer către locația acestuia în șir.
strstr: caută prima apariție a unui șir de caracter în alt șir de caracter și returnează un pointer către locația acestuia în șirul sursă.
toupper: convertește un caracter în majusculă.
tolower: convertește un caracter în minusculă.
isdigit: verifică dacă un caracter este un număr.
isalpha: verifică dacă un caracter este o literă.
isalnum: verifică dacă un caracter este o literă sau un număr.
isspace: verifică dacă un caracter este un spațiu sau un separator.
strrev:inversul sirului;
strtok: împarte un șir de caractere în token-uri, utilizând un set de caractere separatori specific. */
