#include <iostream>

using namespace std;

int main()
{
    int numar_persoane;
    cout<<"Introduceti numarul de persoane din grup: ";
    cin>>numar_persoane;

   Persoana*persoane=new Persoana[numar_persoane];

    for (int i=0;i<numar_persoane;i++)
    {
        cout<<"introduceti numele persoanei " << i + 1 << ": ";
        cin>>persoane[i].nume;
        cout<<"Introduceti prenumele persoanei " << i + 1 << ": ";
        cin>>persoane[i].prenume;
        cout<<"Introduceti varsta persoanei " << i + 1 << ": ";
        cin>>persoane[i].vs;
    }

    cout<<endl<<"Datele introduse sunt: "<<endl;
    for (int i=0; i<numar_persoane;i++)
    {
        cout<<persoane[i].nume<<"\t"<<persoane[i].prenume<<"\t"<<persoane[i].vs<<endl;
    }

    Pers p2(20, "Ionescu", "George");
    Pers* p3=new Pers(21,"Ionescu","Adina");
    cout<<p2.arata_nume()<<"\t"<<p2.arata_vs()<<endl;
    cout<<p3->arata_nume()<<"\t"<<p3->arata_vs()<<endl;

    delete[] persoane;
    Console::ReadKey();
    return 0;
}
